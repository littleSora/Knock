import { api, h, icon, errText, toast, avatarEl, groupAvatarEl, openModal, confirmDialog, friendActions, statusChip, activeStatus } from './common.js';
import { REACTION_EMOJI, IMAGE_BODY } from './reactions.js';
import { prepareChatImage, uploadChatImage, imageErrorText, imagePicker, openImageViewer, PICK_TYPES } from './chat-media.js';
import { cropAvatar } from './cropper.js';
import { safetyActions, openReport } from './safety.js';
import { profileButton } from './account.js';
import * as notify from './notify.js';
import { startAutoStatus, setMyStatus } from './autostatus.js';

const S = { meId: null, groups: [], friends: [], notif: { inbox: [], spam: [], requests: [], accepted: [], groups: [], badge: 0, spamUnread: 0 }, tab: 'inbox', chat: null, groupInfo: null, chats: [], inCall: false, sessionId: null, share: true, typing: new Map(), typingTarget: null, typingSentAt: 0, pickFor: null, menuFor: null, editing: null, editDraft: '', highlight: null };
const fmtDate = (ms) => new Date(ms).toLocaleDateString([], { year: 'numeric', month: 'long', day: 'numeric' });
const fmtStamp = (ms) => `${fmtDate(ms)} at ${new Date(ms).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}`;
let bar, badgeEl, chatBadgeEl, panels, sock;

// Search + friends + notifications, shared by the normal top bar and the in-call bar.
function buildTools() {
  // Search -> opens a profile (that's where the add-friend icon lives)
  const results = h('ul', { class: 'search-results rows', hidden: true });
  const input = h('input', { type: 'search', placeholder: 'Find people', 'aria-label': 'Find people', autocomplete: 'off' });
  let timer;
  input.addEventListener('input', () => {
    clearTimeout(timer);
    timer = setTimeout(async () => {
      const q = input.value.trim();
      if (q.length < 2) { results.hidden = true; return; }
      const { users } = await api('/api/users/search?q=' + encodeURIComponent(q)).catch(() => ({ users: [] }));
      results.replaceChildren(...(users.length
        ? users.map((u) => h('li', { class: 'row' }, h('a', { class: 'row-main', href: '/u/' + u.handle, ...newTab() }, h('span', { class: 'name' }, u.display_name), h('span', { class: 'sub' }, '@' + u.handle))))
        : [h('li', { class: 'empty' }, 'No one found. Try their @handle.')]));
      results.hidden = false;
    }, 250);
  });

  badgeEl = h('span', { class: 'badge', hidden: true });
  chatBadgeEl = h('span', { class: 'badge', hidden: true });
  panels = { friends: h('div', { class: 'panel', hidden: true }), chats: h('div', { class: 'panel', hidden: true }), notif: h('div', { class: 'panel', hidden: true }) };
  const friendsBtn = h('button', { class: 'icon-btn', 'aria-label': 'Friends', onclick: () => togglePanel('friends') }, icon('users'));
  const chatsBtn = h('button', { class: 'icon-btn', 'aria-label': 'Chats', title: 'Chats', onclick: () => togglePanel('chats') }, icon('messages'), chatBadgeEl);
  const bellBtn = h('button', { class: 'icon-btn', 'aria-label': 'Notifications', onclick: () => togglePanel('notif') }, icon('bell'), badgeEl);
  return { search: h('div', { class: 'search' }, input, results), friendsBtn, chatsBtn, bellBtn };
}
function wirePanels() {
  // Switching Inbox/Spam re-renders the panel, which detaches the clicked tab before this handler runs.
  // composedPath() is captured when the click starts, so a click inside the bar still counts as inside.
  document.addEventListener('click', (e) => { if (!e.composedPath().includes(bar)) closePanels(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closePanels(); });
  connect();
}
// A message that is just this site's call link is a call invite: show "Call invite" in previews instead of the raw link.
const isInvite = (b) => typeof b === 'string' && b.startsWith(location.origin + '/s/') && !/\s/.test(b);
const previewText = (b) => (b === '' ? 'Message deleted' : isInvite(b) ? 'Call invite' : b);
// In a call, anything that would navigate (profiles, call invites) opens in a new tab so you never drop out of the call.
const newTab = () => (S.inCall ? { target: '_blank', rel: 'noopener' } : {});

export function mountTopbar(user) {
  bar = document.getElementById('topbar');
  S.meId = user?.id ?? null;
  const brand = h('a', { class: 'brand', href: user ? '/dashboard' : '/' }, h('span', { class: 'brand-mark' }, 'K'), 'Knock');
  if (!user) {
    bar.replaceChildren(brand, h('nav', { class: 'bar-right' }, h('a', { class: 'btn ghost sm', href: '/login' }, 'Log in'), h('a', { class: 'btn sm', href: '/login?mode=signup' }, 'Sign up')));
    return;
  }
  const { search, friendsBtn, chatsBtn, bellBtn } = buildTools();
  const logout = h('button', { class: 'btn ghost sm', onclick: async () => { await api('/api/auth/logout', { method: 'POST' }); location.href = '/'; } }, 'Log out');
  bar.replaceChildren(brand, h('nav', { class: 'bar-right' }, search, friendsBtn, chatsBtn, bellBtn, logout, profileButton(user), panels.friends, panels.chats, panels.notif));
  wirePanels();
}

/**
 * The top-right tools inside a call: find people, friends, notifications and direct messages, with the
 * "Copy invite link" button right next to them. `nav` already holds that button; `sessionId` is this call, so
 * "Invite to call" in a chat sends this call's link instead of starting a different one.
 */
export function mountRoomTools(nav, user, sessionId) {
  bar = nav;
  S.meId = user?.id ?? null;
  S.inCall = true;
  S.sessionId = sessionId;
  document.body.classList.add('in-call');
  const { search, friendsBtn, chatsBtn, bellBtn } = buildTools();
  const copy = nav.querySelector('#copy');
  nav.replaceChildren(copy, search, friendsBtn, chatsBtn, bellBtn, profileButton(user), panels.friends, panels.chats, panels.notif);
  wirePanels();
}

function closePanels() { Object.values(panels).forEach((p) => (p.hidden = true)); bar.querySelector('.search-results').hidden = true; }
function togglePanel(name) {
  const opening = panels[name].hidden;
  closePanels();
  if (!opening) return;
  panels[name].hidden = false;
  if (name === 'chats') { renderChats(); refreshChats(); }
  else if (name === 'friends') { renderFriends(); refreshFriends(); refreshGroups(); } // always show the server's current online/offline status
  else { renderNotif(); api('/api/notifications/read', { method: 'POST' }).then(refreshNotif); }
}

/* ---------- friends panel: Unfriend on the left, presence dot on the right, online first ---------- */
const sortFriends = () => S.friends.sort((a, b) => b.online - a.online || a.display_name.localeCompare(b.display_name));
async function refreshFriends() { S.friends = (await api('/api/friends')).friends; renderFriends(); paintDmStatus(); }
async function refreshGroups() { S.groups = (await api('/api/groups').catch(() => ({ groups: [] }))).groups; renderFriends(); }

function friendRow(f) {
  return h('li', { class: 'row' },
    h('button', { class: 'link-btn danger', 'aria-label': `Unfriend ${f.display_name}`, onclick: () => unfriend(f) }, 'Unfriend'),
    h('button', { class: 'row-main', onclick: () => openChat(f) }, h('span', { class: 'name' }, f.display_name), h('span', { class: 'sub' }, '@' + f.handle)),
    statusChip(f.status),
    h('span', { class: 'dot ' + (f.online ? 'on' : 'off'), role: 'img', 'aria-label': f.online ? 'Online' : 'Offline' }));
}
const groupUnread = (id) => S.notif.groups.find((x) => x.id === id)?.unread || 0;
const countText = (n) => (n > 9 ? '9+' : String(n));
const groupRow = (g) => {
  const n = groupUnread(g.id);
  return h('li', { class: 'row' },
    groupAvatarEl(g, 34),
    h('button', { class: 'row-main', onclick: () => openGroupChat(g) }, h('span', { class: 'name' }, g.name), h('span', { class: 'sub' }, `${g.member_count} members`)),
    n ? h('span', { class: 'count-pill', role: 'img', 'aria-label': `${n} unread` }, countText(n)) : null);
};
function renderFriends() {
  if (!panels) return;
  const section = (label, list, row) => (list.length ? [h('h3', {}, `${label} (${list.length})`), h('ul', { class: 'rows' }, list.map(row))] : []);
  panels.friends.replaceChildren(...[
    // Groups sit above Friends and are hidden entirely until you're in one.
    ...(S.groups.length ? [h('h2', {}, 'Groups'), h('ul', { class: 'rows' }, S.groups.map(groupRow))] : []),
    h('h2', {}, 'Friends'),
    ...(S.friends.length ? [] : [h('p', { class: 'empty' }, 'No friends yet. Open someone’s profile and tap Add friend.')]),
    ...section('Online', S.friends.filter((f) => f.online), friendRow),
    ...section('Offline', S.friends.filter((f) => !f.online), friendRow),
  ]);
}
// The friend's status line in the open direct chat's header.
function paintDmStatus() {
  const el = document.getElementById('dm-status');
  if (el && S.chat?.user) el.replaceChildren(...[statusChip(S.friends.find((x) => x.id === S.chat.user.id)?.status)].filter(Boolean));
}
async function unfriend(f) {
  if (!confirm(`Remove ${f.display_name} from your friends?`)) return;
  await api('/api/friends/' + f.id, { method: 'DELETE' }).catch((e) => toast(errText(e)));
  S.friends = S.friends.filter((x) => x.id !== f.id);
  renderFriends();
}

/* ---------- notifications: Inbox (friends) and Spam (everyone else) ---------- */
const sumUnread = (list) => list.reduce((n, t) => n + t.unread, 0);
// Recomputed locally too, so pressing an unread item clears it instantly instead of after a round trip.
function paintBadge() {
  const n = S.notif;
  n.badge = sumUnread(n.inbox) + sumUnread(n.groups) + n.requests.filter((r) => !r.seen_at).length + n.accepted.filter((a) => !a.read_at).length;
  n.spamUnread = sumUnread(n.spam);
  badgeEl.textContent = n.badge > 9 ? '9+' : n.badge;
  badgeEl.hidden = !n.badge;
}
async function markAllRead() {
  try { await api('/api/notifications/read-all', { method: 'POST' }); } catch (e) { toast(errText(e)); }
  refreshNotif();
}
async function refreshNotif() {
  S.notif = await api('/api/notifications');
  paintBadge();
  refreshChats();
  if (!panels.notif.hidden) renderNotif();
  if (!panels.friends.hidden) renderFriends();
}
const threadRow = (t) => h('li', { class: 'row' },
  h('button', { class: 'row-main', onclick: () => { t.unread = 0; paintBadge(); openChat(t); } }, h('span', { class: 'name' }, t.display_name), h('span', { class: 'sub' }, previewText(t.body))),
  t.unread ? h('span', { class: 'dot new', role: 'img', 'aria-label': `${t.unread} unread` }) : null);
// A friend request with Accept / Decline right in the bell.
function requestRow(r) {
  const act = async (verb, message) => {
    try {
      await api(`/api/friends/requests/${r.id}/${verb}`, { method: 'POST' });
      if (message) toast(message);
    } catch (e) { toast(errText(e)); }
    refreshNotif();
    refreshFriends();
  };
  return h('li', { class: 'row request-row' },
    avatarEl(r, 34),
    h('div', { class: 'row-main pick-text' },
      h('a', { class: 'name', href: '/u/' + r.handle, ...newTab() }, r.display_name),
      h('span', { class: 'sub' }, 'wants to be your friend'),
      h('span', { class: 'request-btns' },
        h('button', { class: 'btn primary sm', type: 'button', onclick: () => act('accept', `You and ${r.display_name} are now friends.`) }, 'Accept'),
        h('button', { class: 'btn sm', type: 'button', onclick: () => act('decline') }, 'Decline'))),
    r.seen_at ? null : h('span', { class: 'dot new', role: 'img', 'aria-label': 'New' }));
}
function renderNotif() {
  const n = S.notif;
  const tab = (id, label, count) => h('button', { class: 'tab' + (S.tab === id ? ' on' : ''), role: 'tab', 'aria-selected': String(S.tab === id), onclick: () => { S.tab = id; renderNotif(); } }, label, count ? h('span', { class: 'count' }, count) : null);
  let body;
  if (S.tab === 'inbox') {
    const requests = n.requests.map(requestRow);
    const accepted = n.accepted.map((a) => h('li', { class: 'row' },
      h('a', { class: 'row-main', href: '/u/' + a.handle, ...newTab() }, h('span', { class: 'name' }, `${a.display_name} accepted your friend request`), h('span', { class: 'sub' }, 'View profile')),
      a.read_at ? null : h('span', { class: 'dot new', role: 'img', 'aria-label': 'New' })));
    const groups = n.groups.map((g) => h('li', { class: 'row' },
      h('button', { class: 'row-main', onclick: () => { g.unread = 0; S.notif.groups = S.notif.groups.filter((x) => x !== g); paintBadge(); openGroupChat(g); } }, h('span', { class: 'name' }, g.name), h('span', { class: 'sub' }, `${g.from_name}: ${previewText(g.body)}`)),
      h('span', { class: 'count-pill', role: 'img', 'aria-label': `${g.unread} unread` }, countText(g.unread))));
    const rows = [...requests, ...accepted, ...groups, ...n.inbox.filter((t) => t.unread > 0).map(threadRow)]; // read conversations live in Chats
    body = rows.length ? h('ul', { class: 'rows' }, rows) : h('p', { class: 'empty' }, 'Nothing new. Unread messages and friend requests show up here; read conversations are under Chats.');
  } else {
    body = n.spam.length ? [h('p', { class: 'hint' }, 'Messages from people who aren’t on your friend list.'), h('ul', { class: 'rows' }, n.spam.map(threadRow))] : h('p', { class: 'empty' }, 'No spam. Messages from people you haven’t added land here.');
  }
  panels.notif.replaceChildren(...[
    h('div', { class: 'tabs', role: 'tablist' }, tab('inbox', 'Inbox', n.badge), tab('spam', 'Spam', n.spamUnread)),
    n.badge || n.spamUnread ? h('div', { class: 'panel-tools' }, h('button', { class: 'link-btn', type: 'button', onclick: markAllRead }, 'Mark all as read')) : null,
    body,
  ].flat().filter(Boolean)); // (replaceChildren would print null/arrays as text)
}

/* ---------- chats panel: all your conversations, newest first, plus a way to start a new one ---------- */
async function refreshChats() {
  try { S.chats = (await api('/api/chats')).chats; } catch { return; }
  const unread = S.chats.reduce((n, c) => n + c.unread, 0);
  chatBadgeEl.textContent = countText(unread);
  chatBadgeEl.hidden = !unread;
  if (!panels.chats.hidden) renderChats();
}
const shortWhen = (ms) => {
  const d = new Date(ms);
  return d.toDateString() === new Date().toDateString() ? d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) : d.toLocaleDateString([], { month: 'short', day: 'numeric' });
};
const previewOf = (c) => {
  if (c.preview == null) return 'No messages yet';
  const text = previewText(c.preview);
  const who = c.type === 'group' ? (c.mine ? 'You: ' : `${c.from_name}: `) : c.mine ? 'You: ' : '';
  return who + text;
};
function chatRow(c) {
  const open = () => (c.type === 'group' ? openGroupChat({ id: c.id, name: c.name, avatar_at: c.avatar_at }) : openChat({ id: c.id, handle: c.handle, display_name: c.display_name, avatar_at: c.avatar_at }));
  const title = c.type === 'group' ? c.name : c.display_name;
  return h('li', { class: 'row' },
    c.type === 'group' ? groupAvatarEl(c, 34) : avatarEl(c, 34),
    h('button', { class: 'row-main chat-row', onclick: open },
      h('span', { class: 'name' }, title, c.type === 'group' ? h('span', { class: 'sub', style: 'margin-left:.4rem' }, `${c.member_count} members`) : null),
      h('span', { class: 'sub' + (c.unread ? ' strong' : '') }, previewOf(c))),
    h('span', { class: 'chat-meta' }, h('span', { class: 'sub' }, shortWhen(c.at)),
      c.unread ? h('span', { class: 'count-pill', role: 'img', 'aria-label': `${c.unread} unread` }, countText(c.unread)) : null));
}
function renderChats() {
  const withChat = new Set(S.chats.filter((c) => c.type === 'dm').map((c) => c.id));
  const fresh = S.friends.filter((f) => !withChat.has(f.id)); // friends you haven't talked to yet
  panels.chats.replaceChildren(...[
    h('h2', {}, 'Chats'),
    S.chats.length ? h('ul', { class: 'rows' }, S.chats.map(chatRow)) : h('p', { class: 'empty' }, 'No chats yet. Pick a friend below to say hi.'),
    ...(fresh.length ? [h('h3', {}, 'Start a new chat'), h('ul', { class: 'rows' }, fresh.map((f) => h('li', { class: 'row' },
      avatarEl(f, 34),
      h('button', { class: 'row-main', onclick: () => openChat(f) }, h('span', { class: 'name' }, f.display_name), h('span', { class: 'sub' }, '@' + f.handle)),
      statusChip(f.status),
      h('span', { class: 'dot ' + (f.online ? 'on' : 'off'), role: 'img', 'aria-label': f.online ? 'Online' : 'Offline' }))))]
      : S.friends.length ? [] : [h('p', { class: 'hint' }, 'Add a friend to start a conversation.')]),
  ]);
}

/* ---------- direct-message dock ---------- */
function imageEl(m) {
  const src = `/api/chat-images/${m.image_id}`;
  const img = h('img', { src, alt: 'Picture in the chat', draggable: 'false' });
  img.addEventListener('load', () => { const l = document.getElementById('chat-list'); if (l && S.chatStuck) l.scrollTop = l.scrollHeight; }); // a late-loading picture shouldn't push the newest message out of view
  return h('button', { class: 'chat-img', type: 'button', 'aria-label': 'Open picture', onclick: () => openImageViewer(src) }, img);
}
// Reaction chips under a message (tap one to add or remove yours) and a small button that opens the emoji row.
function reactionsEl(m) {
  const list = m.reactions || [];
  const picking = S.pickFor === m.id;
  const chips = list.map((r) => {
    const mine = r.users.includes(S.meId);
    return h('button', { class: 'react-chip' + (mine ? ' mine' : ''), type: 'button', 'aria-pressed': String(mine), 'aria-label': `${r.emoji} ${r.users.length}${mine ? ', you reacted' : ''}`, onclick: () => react(m, r.emoji) }, r.emoji, h('span', {}, String(r.users.length)));
  });
  const add = h('button', { class: 'react-add', type: 'button', 'aria-label': 'Add a reaction', 'aria-expanded': String(picking), onclick: () => { S.pickFor = picking ? null : m.id; renderChatList(false); } }, icon('smile', 15));
  const pick = picking
    ? h('div', { class: 'react-pick', role: 'group', 'aria-label': 'Pick a reaction' }, REACTION_EMOJI.map((e) => h('button', { class: 'react-opt', type: 'button', 'aria-label': `React ${e}`, onclick: () => { S.pickFor = null; react(m, e); } }, e)))
    : null;
  const own = isMine(m);
  const act =(label, fn, danger = false) => h('button', { class: 'msg-act' + (danger ? ' danger' : ''), type: 'button', onclick: fn }, label);
  const actions = [act(m.pinned ? 'Unpin' : 'Pin', () => togglePin(m)), own && canEdit(m) ? act('Edit', () => startEdit(m)) : null, own ? act('Delete', () => deleteMessage(m), true) : null];
  return h('div', { class: 'reacts' }, chips, add, ...actions, pick);
}
async function react(m, emoji) {
  const chat = S.chat;
  if (!chat) return;
  try {
    const url = chat.group ? `/api/groups/${chat.group.id}/messages/${m.id}/react` : `/api/messages/${m.id}/react`;
    m.reactions = (await api(url, { method: 'PUT', body: { emoji } })).reactions;
    if (S.chat === chat) renderChatList(false);
  } catch (err) { toast(errText(err)); }
}
// One message: the bubble (text and/or picture) plus its reactions.
function bubbleEl(m, mine, content, who = null) {
  if (m.deleted) return h('div', { class: 'msg-wrap' + (mine ? ' mine' : ''), 'data-mid': String(m.id) }, h('div', { class: 'msg deleted' }, mine ? 'You deleted this message' : 'This message was deleted'));
  if (S.editing === m.id) return editEl(m, mine);
  const pic = !!m.image_id;
  const caption = pic && m.body !== IMAGE_BODY ? m.body : null;
  const bubble = h('div', { class: 'msg' + (mine ? ' mine' : '') + (pic ? ' has-img' : '') }, who, pic ? imageEl(m) : null, pic ? (caption ? h('span', { class: 'caption' }, caption) : null) : content);
  const meta = m.pinned || m.edited_at ? h('div', { class: 'msg-meta' }, m.pinned ? h('span', { class: 'pin-mark' }, icon('pin', 12), 'Pinned') : null, m.edited_at ? h('span', {}, 'Edited') : null) : null;
  return h('div', { class: 'msg-wrap' + (mine ? ' mine' : '') + (S.highlight === m.id ? ' hit' : ''), 'data-mid': String(m.id) }, bubble, meta, reactionsEl(m));
}
function msgEl(m, other) {
  const isLink = isInvite(m.body) && !m.image_id; // same-origin call invite
  const here = S.inCall && isLink && m.body === `${location.origin}/s/${S.sessionId}`; // an invite to the call you're already in
  const mine = m.from_id !== other.id;
  let content = m.body;
  if (here) content = mine ? 'You invited them to this call' : 'Invited you to this call (you’re already in it)';
  else if (isLink) content = h('a', { href: m.body, rel: 'noopener', ...(S.inCall ? { target: '_blank' } : {}) }, mine ? 'Your call invite' : 'Join my call');
  return bubbleEl(m, mine, content);
}
function appendMsg(m) {
  if (!S.chat || S.chat.messages.some((x) => x.id === m.id)) return;
  if (S.chat.latest === false) { // showing an older stretch (from a search): your own message takes you back to the end, others wait behind "Jump to latest"
    if (m.from_id === S.meId) jumpLatest();
    return;
  }
  S.chat.messages.push(m);
  const t = S.typing.get(m.from_id); // their message arrived, so "typing…" is over
  if (t) { clearTimeout(t.timer); S.typing.delete(m.from_id); paintTyping(); }
  renderChatList(true);
}

/* ---------- edit, delete and pin ---------- */
const chatBase = (c) => (c.group ? `/api/groups/${c.group.id}/messages` : '/api/messages');
const isMine = (m) => (S.chat.group ? m.from_id === S.meId : m.from_id !== S.chat.user.id);
const canEdit = (m) => !m.deleted && !(m.image_id && m.body === IMAGE_BODY); // a picture with no caption has no text
// The same change reaches this tab twice (the API reply and the live event) and other tabs / the other person once; applying it again is harmless.
function applyChange(message, kind, gid) {
  if (message.deleted) refreshNotif(); else refreshChats(); // the Chats list shows previews, and a deletion can lower unread counts
  const c = S.chat;
  if (!c) return;
  const here = kind === 'group' ? c.group?.id === gid : !c.group && (message.from_id === c.user.id || message.to_id === c.user.id);
  if (!here) return;
  const w = c.messages.find((x) => x.id === message.id);
  if (w) Object.assign(w, message);
  const i = c.pins.findIndex((p) => p.id === message.id);
  if (message.pinned && !message.deleted) { if (i >= 0) Object.assign(c.pins[i], message); else c.pins.unshift({ ...message }); }
  else if (i >= 0) c.pins.splice(i, 1);
  if (message.deleted && S.editing === message.id) { S.editing = null; S.editDraft = ''; }
  renderChatList(false);
}
const kindOf = (c) => (c.group ? 'group' : 'dm');
function startEdit(m) {
  S.editing = m.id; S.editDraft = m.body; S.menuFor = null; S.pickFor = null;
  renderChatList(false);
  document.getElementById('edit-input')?.focus();
}
function cancelEdit() { S.editing = null; S.editDraft = ''; renderChatList(false); }
async function saveEdit(m) {
  const body = S.editDraft.trim();
  if (!body) { toast(errText({ code: 'invalid_message' })); return; }
  if (body === m.body) return cancelEdit();
  const chat = S.chat;
  try {
    const { message } = await api(`${chatBase(chat)}/${m.id}`, { method: 'PATCH', body: { body } });
    S.editing = null; S.editDraft = '';
    applyChange(message, kindOf(chat), chat.group?.id);
  } catch (err) { toast(errText(err)); }
}
function editEl(m, mine) {
  const input = h('input', { type: 'text', id: 'edit-input', maxlength: '2000', value: S.editDraft, 'aria-label': 'Edit message', autocomplete: 'off' });
  input.addEventListener('input', () => { S.editDraft = input.value; }); // kept, so an incoming message redrawing the chat doesn't lose what you typed
  input.addEventListener('keydown', (e) => { if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); cancelEdit(); } });
  return h('div', { class: 'msg-wrap edit' + (mine ? ' mine' : ''), 'data-mid': String(m.id) },
    h('form', { class: 'msg-edit', onsubmit: (e) => { e.preventDefault(); saveEdit(m); } }, input,
      h('button', { class: 'btn primary sm', type: 'submit' }, 'Save'), h('button', { class: 'btn sm', type: 'button', onclick: cancelEdit }, 'Cancel')));
}
async function deleteMessage(m) {
  S.menuFor = null;
  renderChatList(false);
  const ok = await confirmDialog({ title: 'Delete this message?', body: 'It disappears for everyone in this chat. This can’t be undone.', confirmText: 'Delete' });
  if (!ok) return;
  const chat = S.chat;
  try {
    const { message } = await api(`${chatBase(chat)}/${m.id}`, { method: 'DELETE' });
    applyChange(message, kindOf(chat), chat.group?.id);
  } catch (err) { toast(errText(err)); }
}
async function togglePin(m) {
  S.menuFor = null;
  const chat = S.chat;
  try {
    const { message } = await api(`${chatBase(chat)}/${m.id}/pin`, { method: 'PUT', body: { pinned: !m.pinned } });
    applyChange(message, kindOf(chat), chat.group?.id);
  } catch (err) { toast(errText(err)); renderChatList(false); }
}

/* ---------- pinned messages: a bar under the chat's header, and a list with Show / Unpin ---------- */
const pinText = (p) => (p.image_id && p.body === IMAGE_BODY ? '📷 Photo' : previewText(p.body));
const pinWho = (p) => (p.from_id === S.meId ? 'You' : S.chat.group ? p.from_name : S.chat.user.display_name);
function paintPins() {
  const bar = document.getElementById('pin-bar');
  if (!bar || !S.chat) return;
  const pins = S.chat.pins;
  bar.hidden = !pins.length;
  bar.replaceChildren(...(pins.length ? [h('button', { class: 'pin-open', type: 'button', 'aria-haspopup': 'dialog', title: 'Pinned messages', onclick: openPins },
    icon('pin', 14), h('span', { class: 'pin-text' }, `${pinWho(pins[0])}: ${pinText(pins[0])}`), pins.length > 1 ? h('span', { class: 'pin-more' }, `+${pins.length - 1}`) : null)] : []));
}
function openPins() {
  const chat = S.chat;
  if (!chat?.pins.length) return;
  const body = h('div', {});
  const closeBtn = h('button', { class: 'icon-btn sm', type: 'button', 'aria-label': 'Close pinned messages', onclick: () => m.close() }, icon('x', 16));
  const m = openModal({ label: 'Pinned messages', wide: true }, h('div', { class: 'pop-head' }, h('strong', {}, 'Pinned messages'), h('span', { class: 'grow' }), closeBtn), body);
  const paint = () => {
    if (S.chat !== chat || !chat.pins.length) { m.close(); return; }
    body.replaceChildren(h('ul', { class: 'rows' }, chat.pins.map((p) => h('li', { class: 'row' },
      h('div', { class: 'row-main pick-text' }, h('span', { class: 'name' }, `${pinWho(p)} · ${shortWhen(p.created_at)}`), h('span', { class: 'sub pin-snippet' }, pinText(p))),
      h('button', { class: 'link-btn', type: 'button', onclick: () => { m.close(); jumpTo(p.id); } }, 'Show'),
      h('button', { class: 'link-btn danger', type: 'button', onclick: async () => { await togglePin(p); paint(); } }, 'Unpin')))));
  };
  paint();
}

/* ---------- search inside a chat, and jumping to a result ---------- */
// The chat only holds its newest messages, so a hit further back is loaded as a window of messages around it.
// While you're looking at such a window, new messages wait behind a "Jump to latest" bar.
async function loadChat(around) {
  const c = S.chat;
  const q = around ? `?around=${around}` : '';
  const r = await api(c.group ? `/api/groups/${c.group.id}/messages${q}` : `/api/messages/with/${c.user.id}${q}`);
  if (S.chat !== c) return false;
  c.messages = r.messages;
  c.pins = r.pins || [];
  c.latest = r.latest !== false;
  if (c.group) c.reads = r.reads || c.reads;
  return true;
}
async function jumpLatest() {
  try { if (await loadChat(null)) { S.highlight = null; renderChatList(true); refreshNotif(); } } catch (err) { toast(errText(err)); }
}
async function jumpTo(id) {
  closeSearch();
  if (!S.chat) return;
  try {
    if (!S.chat.messages.some((m) => m.id === id) && !(await loadChat(id))) return;
  } catch (err) { toast(errText(err)); return; }
  S.highlight = id;
  renderChatList(false);
  S.chatStuck = false;
  document.querySelector(`#chat-list [data-mid="${id}"]`)?.scrollIntoView({ block: 'center' });
  setTimeout(() => { // the highlight fades after a moment
    if (S.highlight !== id) return;
    S.highlight = null;
    document.querySelector(`#chat-list [data-mid="${id}"]`)?.classList.remove('hit');
  }, 2500);
}
function closeSearch() { document.getElementById('chat-dock')?.classList.remove('searching'); }
function toggleSearch() {
  const dock = document.getElementById('chat-dock');
  if (!dock) return;
  if (dock.classList.contains('searching')) return closeSearch();
  dock.classList.add('searching');
  const input = document.getElementById('chat-search-input');
  input?.focus();
  input?.select();
}
const searchBtn = () => h('button', { class: 'icon-btn sm', type: 'button', 'aria-label': 'Search this chat', title: 'Search this chat', onclick: toggleSearch }, icon('search', 16));
function hitEl(r, q) {
  const text = r.body.replace(/\s+/g, ' ');
  const i = text.toLowerCase().indexOf(q.toLowerCase());
  const from = Math.max(0, i - 30);
  const snippet = i < 0 ? [text.slice(0, 110)] : [from > 0 ? '…' : '', text.slice(from, i), h('mark', {}, text.slice(i, i + q.length)), text.slice(i + q.length, i + q.length + 80)];
  const who = r.from_id === S.meId ? 'You' : S.chat.group ? r.from_name : S.chat.user.display_name;
  return h('button', { class: 'search-hit', type: 'button', onclick: () => jumpTo(r.id) },
    h('span', { class: 'hit-meta' }, `${who} · ${shortWhen(r.created_at)}`), h('span', { class: 'hit-text' }, snippet));
}
function searchPanel() {
  const input = h('input', { type: 'search', id: 'chat-search-input', maxlength: '100', placeholder: 'Search this chat', 'aria-label': 'Search this chat', autocomplete: 'off' });
  const list = h('div', { class: 'search-list', role: 'region', 'aria-live': 'polite', 'aria-label': 'Search results' }, h('p', { class: 'hint' }, 'Type at least 2 letters.'));
  let timer;
  let seq = 0;
  async function run() {
    const q = input.value.trim();
    const mine = ++seq;
    if (q.length < 2) { list.replaceChildren(h('p', { class: 'hint' }, 'Type at least 2 letters.')); return; }
    const chat = S.chat;
    if (!chat) return;
    try {
      const url = chat.group ? `/api/groups/${chat.group.id}/messages/search?q=` : `/api/messages/with/${chat.user.id}/search?q=`;
      const { results } = await api(url + encodeURIComponent(q));
      if (mine !== seq || S.chat !== chat) return; // a newer search has started
      list.replaceChildren(...(results.length ? results.map((r) => hitEl(r, q)) : [h('p', { class: 'empty' }, `No messages match “${q}”.`)]));
    } catch (err) { list.replaceChildren(h('p', { class: 'error' }, errText(err))); }
  }
  input.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(run, 250); });
  input.addEventListener('keydown', (e) => { if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); closeSearch(); } });
  return h('div', { class: 'chat-search', id: 'chat-search' }, h('div', { class: 'search-row' }, input, h('button', { class: 'icon-btn sm', type: 'button', 'aria-label': 'Close search', onclick: closeSearch }, icon('x', 16))), list);
}
const latestBar = () => h('div', { class: 'latest-bar', id: 'latest-bar', hidden: true }, h('button', { class: 'link-btn', type: 'button', onclick: jumpLatest }, 'You’re looking at older messages. Jump to latest'));

/* ---------- "Seen" receipts and typing indicators ---------- */
// Redraws the open chat. The "Sent / Seen" line sits under the last message you sent.
function renderChatList(stick) {
  const list = document.getElementById('chat-list');
  if (!list || !S.chat) return;
  const atBottom = list.scrollHeight - list.scrollTop - list.clientHeight < 40;
  const editing = document.activeElement?.id === 'edit-input'; // a redraw (say, a new message) must not take the cursor away
  const g = S.chat.group;
  const msgs = S.chat.messages;
  const mine = (m) => (g ? m.from_id === S.meId && m.kind !== 'system' : m.from_id !== S.chat.user.id);
  const els = msgs.map((m) => (g ? groupMsgEl(m) : msgEl(m, S.chat.user)));
  const last = msgs.findLastIndex((m) => mine(m) && !m.deleted);
  const r = last >= 0 ? receiptEl(msgs[last]) : null;
  if (r) els.splice(last + 1, 0, r);
  list.replaceChildren(...els);
  S.chatStuck = !!(stick || atBottom);
  if (S.chatStuck) list.scrollTop = list.scrollHeight;
  if (editing) { const e = document.getElementById('edit-input'); if (e) { e.focus(); e.setSelectionRange(e.value.length, e.value.length); } }
  paintPins();
  const bar = document.getElementById('latest-bar');
  if (bar) bar.hidden = S.chat.latest !== false;
}
function receiptEl(m) {
  if (!S.share) return null; // if you keep yours private you don't see anyone's either
  const c = S.chat;
  let text;
  if (c.group) {
    const reads = c.reads || [];
    const seen = reads.filter((r) => r.last_read_id != null && r.last_read_id >= m.id);
    text = !seen.length ? 'Sent' : seen.length === reads.length ? 'Seen by everyone'
      : 'Seen by ' + (seen.length > 2 ? `${seen[0].name}, ${seen[1].name} +${seen.length - 2}` : seen.map((r) => r.name).join(', '));
  } else text = m.read_at ? `Seen ${shortWhen(m.read_at)}` : 'Sent';
  return h('div', { class: 'receipt' }, text);
}
function typingText() {
  const names = [...S.typing.values()].map((t) => t.name);
  if (!names.length) return '';
  if (names.length === 1) return `${names[0]} is typing`;
  if (names.length === 2) return `${names[0]} and ${names[1]} are typing`;
  return 'Several people are typing';
}
function paintTyping() {
  const el = document.getElementById('chat-status');
  if (!el) return;
  const text = S.share ? typingText() : '';
  el.replaceChildren(...(text ? [h('span', { class: 'typing-dots', 'aria-hidden': 'true' }, h('i'), h('i'), h('i')), text + '…'] : []));
}
function clearTyping() { S.typing.forEach((t) => clearTimeout(t.timer)); S.typing.clear(); paintTyping(); }
// Tell the other side we're typing (at most every 2.5 s while keys are pressed; they hide it after 5 s of silence).
function wireTyping(input, target) {
  stopTyping();
  clearTyping();
  S.typingTarget = target;
  input.addEventListener('input', () => {
    if (!S.share || !sock?.connected) return;
    if (!input.value.trim()) return stopTyping();
    const now = Date.now();
    if (now - S.typingSentAt > 2500) { S.typingSentAt = now; sock.emit('typing', { ...target, on: true }); }
  });
  input.addEventListener('blur', stopTyping);
}
function stopTyping() {
  if (S.typingSentAt && S.typingTarget && sock?.connected) sock.emit('typing', { ...S.typingTarget, on: false });
  S.typingSentAt = 0;
}
function closeChat() { stopTyping(); clearTyping(); S.chat = null; S.pickFor = null; S.menuFor = null; S.editing = null; S.editDraft = ''; S.highlight = null; document.getElementById('chat-dock')?.remove(); }

// The picture button for a chat's message box. `send(blob, caption)` uploads and resolves with the new message; anything
// typed in the box goes along as the caption.
function picturePicker(input, send) {
  let btn;
  const [button, file] = imagePicker(async (f) => {
    const caption = input.value.trim().slice(0, 500);
    btn.disabled = true;
    try {
      const blob = await prepareChatImage(f);
      const { message } = await send(blob, caption);
      input.value = '';
      stopTyping();
      appendMsg(message);
    } catch (err) { toast(imageErrorText(err) || errText(err)); }
    finally { btn.disabled = false; }
  });
  btn = button;
  return [button, file];
}

async function openChat(u, { focus = true } = {}) {
  if (focus) closePanels();
  const { messages, pins } = await api('/api/messages/with/' + u.id);
  stopTyping();
  S.chat = { user: { id: u.id, display_name: u.display_name }, messages, pins: pins || [], latest: true };
  S.pickFor = null; S.menuFor = null; S.editing = null; S.editDraft = '';
  document.getElementById('chat-dock')?.remove();
  const input = h('input', { type: 'text', maxlength: '2000', placeholder: `Message ${u.display_name}`, 'aria-label': 'Message', autocomplete: 'off' });
  const list = h('div', { class: 'chat-list', id: 'chat-list' });
  const form = h('form', { class: 'chat-form', onsubmit: async (e) => {
    e.preventDefault();
    const body = input.value.trim();
    if (!body) return;
    input.value = '';
    stopTyping();
    try { appendMsg((await api('/api/messages', { method: 'POST', body: { toId: u.id, body } })).message); }
    catch (err) { toast(errText(err)); input.value = body; }
  } }, ...picturePicker(input, (blob, caption) => uploadChatImage(`/api/messages/image?toId=${u.id}${caption ? '&caption=' + encodeURIComponent(caption) : ''}`, blob)), input, h('button', { class: 'btn primary', type: 'submit', 'aria-label': 'Send' }, icon('send', 18)));
  document.body.append(h('aside', { class: 'chat-dock', id: 'chat-dock', 'aria-label': `Chat with ${u.display_name}` },
    h('header', {}, h('button', { class: 'name-btn', type: 'button', 'aria-haspopup': 'dialog', title: 'View profile', onclick: () => openProfileCard(u) }, u.display_name), h('span', { id: 'dm-status' }, statusChip(S.friends.find((x) => x.id === u.id)?.status)), h('span', { class: 'grow' }),
      h('button', { class: 'link-btn', onclick: () => inviteToCall(u) }, 'Invite to call'),
      searchBtn(),
      h('button', { class: 'icon-btn sm', 'aria-label': 'Close chat', onclick: closeChat }, icon('x', 16))),
    h('div', { class: 'pin-bar', id: 'pin-bar', hidden: true }), searchPanel(),
    list, latestBar(), h('div', { class: 'chat-status', id: 'chat-status', role: 'status' }), form));
  wireTyping(input, { to: u.id });
  renderChatList(true);
  if (focus) input.focus();
  refreshNotif();
}
async function inviteToCall(u) {
  try {
    if (S.inCall) { // already in a call: send this call's link and stay here
      await api('/api/messages', { method: 'POST', body: { toId: u.id, body: `${location.origin}/s/${S.sessionId}` } });
      toast(`Invite sent to ${u.display_name}`);
      return;
    }
    const { id } = await api('/api/sessions', { method: 'POST' });
    await api('/api/messages', { method: 'POST', body: { toId: u.id, body: `${location.origin}/s/${id}` } });
    location.href = '/s/' + id;
  } catch (e) { toast(errText(e)); }
}

/* ---------- friend profile card (tap their name in a chat) ---------- */
async function openProfileCard(u) {
  if (!u.handle) return;
  const body = h('div', {}, h('p', { class: 'hint' }, 'Loading…'));
  const closeBtn = h('button', { class: 'icon-btn sm', type: 'button', 'aria-label': 'Close profile', onclick: () => m.close() }, icon('x', 16));
  const m = openModal({ label: `${u.display_name}’s profile`, wide: true }, h('div', { class: 'pop-head' }, h('span', { class: 'grow' }), closeBtn), body);
  try {
    const { user: p, relation: first } = await api('/api/users/' + encodeURIComponent(u.handle));
    const paint = (relation) => {
      const groupBtn = h('button', { class: 'btn primary sm', type: 'button', onclick: () => { m.close(); openGroupCreate({ id: p.id, handle: p.handle, display_name: p.display_name, avatar_at: p.avatar_at }); } },
        h('span', { class: 'btn-ic' }, icon('users', 16)), `Create a group with ${p.display_name}`);
      body.replaceChildren(
        h('div', { class: 'profile-head', style: 'margin-top:0' }, avatarEl(p, 88), h('div', {}, h('h2', { style: 'font-size:1.6rem' }, p.display_name), h('p', { class: 'sub' }, '@' + p.handle), statusChip(p.status))),
        h('dl', { class: 'facts-list' },
          h('dt', {}, 'Username'), h('dd', {}, '@' + p.handle),
          h('dt', {}, 'Name at signup'), h('dd', {}, p.signup_name),
          h('dt', {}, 'Joined'), h('dd', {}, fmtDate(p.created_at)),
          h('dt', {}, 'Friend'), h('dd', {}, { friend: 'Yes, you’re friends', outgoing: 'Friend request sent', incoming: 'Wants to be your friend', blocked: 'Blocked' }[relation] || 'Not friends yet')),
        // Add friend / Request sent / Accept + Decline live here, so a chat with someone you're not friends with can fix that.
        relation === 'self' ? null : friendActions(p, relation, (next) => { paint(next); refreshFriends(); refreshNotif(); }),
        h('div', { class: 'pic-actions' },
          relation === 'friend' ? groupBtn : null, // groups can only include friends
          h('a', { class: 'btn primary sm', href: '/u/' + p.handle, ...newTab() }, h('span', { class: 'btn-ic' }, icon('users', 16)), 'Full profile')),
        relation === 'self' ? null : safetyActions(p, relation, { context: { type: 'dm' }, onChange: (next) => {
          if (next === 'blocked' && S.chat?.user.id === p.id) closeChat(); // a blocked person's chat closes
          paint(next); refreshFriends(); refreshNotif();
        } }));
      (body.querySelector('.friend-actions button, .pic-actions button') || closeBtn).setAttribute('data-autofocus', '');
    };
    paint(first);
  } catch (err) { body.replaceChildren(h('p', { class: 'error' }, errText(err))); }
}

/* ---------- create a group: name it, then optionally add more friends ---------- */
function openGroupCreate(first) {
  let members = [first];
  let groupName = '';
  let view = 'main'; // 'main' | 'pick'
  const body = h('div', {});
  const closeBtn = h('button', { class: 'icon-btn sm', type: 'button', 'aria-label': 'Close', onclick: () => m.close() }, icon('x', 16));
  const m = openModal({ label: 'Create a group', wide: true }, h('div', { class: 'pop-head' }, h('strong', {}, 'New group'), h('span', { class: 'grow' }), closeBtn), body);
  refreshFriends().then(() => view === 'pick' && render()); // make sure the picker has a fresh friend list
  render();

  function render() { (view === 'pick' ? renderPick : renderMain)(); }

  function renderMain() {
    const msg = h('p', { class: 'error', role: 'alert' });
    const nameInput = h('input', { id: 'grpName', maxlength: '40', placeholder: 'Group name', autocomplete: 'off', value: groupName, 'data-autofocus': '' });
    nameInput.addEventListener('input', () => { groupName = nameInput.value; });
    const chips = h('ul', { class: 'chips', 'aria-label': 'Group members' }, members.map((f) => h('li', { class: 'chip' }, f.display_name,
      members.length > 1 ? h('button', { class: 'chip-x', type: 'button', 'aria-label': `Remove ${f.display_name}`, onclick: () => { members = members.filter((x) => x.id !== f.id); render(); } }, icon('x', 12)) : null)));
    const form = h('form', {},
      h('label', { for: 'grpName' }, 'Group name'), nameInput,
      h('h3', {}, `Members (${members.length + 1} with you)`), chips,
      h('button', { class: 'btn sm', type: 'button', onclick: () => { view = 'pick'; render(); } }, h('span', { class: 'btn-ic' }, icon('userPlus', 16)), 'Add another friend'),
      msg,
      h('div', { class: 'dialog-actions' }, h('button', { class: 'btn', type: 'button', onclick: () => m.close() }, 'Cancel'), h('button', { class: 'btn primary', type: 'submit' }, 'Create group')));
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      msg.textContent = '';
      if (!groupName.trim()) { msg.textContent = 'Give your group a name.'; nameInput.focus(); return; }
      try {
        const { group } = await api('/api/groups', { method: 'POST', body: { name: groupName.trim(), memberIds: members.map((x) => x.id) } });
        S.groups.unshift(group);
        renderFriends();
        m.close();
        toast(`Group “${group.name}” created`);
        openGroupChat(group);
      } catch (err) { msg.textContent = errText(err); }
    });
    body.replaceChildren(form);
    nameInput.focus();
  }

  function renderPick() {
    const chosen = new Set(members.map((x) => x.id));
    const available = S.friends.filter((f) => !chosen.has(f.id));
    let list;
    if (!S.friends.length) list = h('p', { class: 'empty' }, 'You don’t have any friends yet. Make a friend first: search for someone at the top of the page, open their profile and tap the add-friend icon.');
    else if (!available.length) list = h('p', { class: 'empty' }, 'Everyone on your friend list is already in this group. Make more friends to add them here.');
    else list = h('ul', { class: 'rows' }, available.map((f) => h('li', { class: 'row' },
      h('button', { class: 'row-main pick-row', type: 'button', onclick: () => { members.push(f); view = 'main'; render(); } },
        avatarEl(f, 34), h('span', { class: 'pick-text' }, h('span', { class: 'name' }, f.display_name), h('span', { class: 'sub' }, '@' + f.handle))),
      h('span', { class: 'dot ' + (f.online ? 'on' : 'off'), role: 'img', 'aria-label': f.online ? 'Online' : 'Offline' }))));
    body.replaceChildren(
      h('h3', { style: 'margin-top:0' }, 'Add a friend to the group'),
      h('p', { class: 'hint' }, 'Tap a friend to add them.'),
      list,
      h('div', { class: 'dialog-actions' }, h('button', { class: 'btn', type: 'button', 'data-autofocus': '', onclick: () => { view = 'main'; render(); } }, 'Back')));
  }
}

/* ---------- group chat dock ---------- */
function groupMsgEl(m) {
  if (m.kind === 'system') return h('div', { class: 'msg note' }, m.body);
  const mine = m.from_id === S.meId;
  let content = m.body;
  if (isInvite(m.body) && !m.image_id) { // a call started for the whole group
    const here = S.inCall && m.body === `${location.origin}/s/${S.sessionId}`;
    content = here ? (mine ? 'You invited the group to this call' : 'Invited the group to this call (you’re already in it)')
      : h('a', { href: m.body, rel: 'noopener', ...(S.inCall ? { target: '_blank' } : {}) }, mine ? 'Your group call' : 'Join the group call');
  }
  return bubbleEl(m, mine, content, mine ? null : h('span', { class: 'who' }, m.from_name));
}
// One tap: start a call and send its link to every member. In a call already, it sends this call's link instead and keeps you here.
let callingGroup = false;
async function callGroup(g) {
  if (callingGroup) return;
  callingGroup = true;
  try {
    const send = (id) => api(`/api/groups/${g.id}/messages`, { method: 'POST', body: { body: `${location.origin}/s/${id}` } });
    if (S.inCall) { await send(S.sessionId); toast(`Call link sent to ${g.name}`); return; }
    const { id } = await api('/api/sessions', { method: 'POST' });
    await send(id);
    location.href = '/s/' + id;
  } catch (e) { toast(errText(e)); }
  finally { callingGroup = false; }
}
async function openGroupChat(g, { focus = true } = {}) {
  if (focus) closePanels();
  let messages, reads, pins;
  try { ({ messages, reads, pins } = await api(`/api/groups/${g.id}/messages`)); } catch (e) { toast(errText(e)); return; }
  stopTyping();
  const known = S.groups.find((x) => x.id === g.id);
  S.chat = { group: { id: g.id, name: g.name, avatar_at: g.avatar_at ?? known?.avatar_at ?? null }, messages, reads: reads || [], pins: pins || [], latest: true };
  S.pickFor = null; S.menuFor = null; S.editing = null; S.editDraft = '';
  document.getElementById('chat-dock')?.remove();
  const input = h('input', { type: 'text', maxlength: '2000', placeholder: `Message ${g.name}`, 'aria-label': 'Message the group', autocomplete: 'off', id: 'group-input' });
  const list = h('div', { class: 'chat-list', id: 'chat-list' });
  const form = h('form', { class: 'chat-form', onsubmit: async (e) => {
    e.preventDefault();
    const body = input.value.trim();
    if (!body) return;
    input.value = '';
    stopTyping();
    try { appendMsg((await api(`/api/groups/${g.id}/messages`, { method: 'POST', body: { body } })).message); }
    catch (err) { toast(errText(err)); input.value = body; }
  } }, ...picturePicker(input, (blob, caption) => uploadChatImage(`/api/groups/${g.id}/messages/image${caption ? '?caption=' + encodeURIComponent(caption) : ''}`, blob)), input, h('button', { class: 'btn primary', type: 'submit', 'aria-label': 'Send' }, icon('send', 18)));
  document.body.append(h('aside', { class: 'chat-dock', id: 'chat-dock', 'aria-label': `Group chat ${g.name}` },
    h('header', {}, h('span', { id: 'group-pic' }, groupAvatarEl(S.chat.group, 28)),
      h('button', { class: 'name-btn', id: 'group-title', type: 'button', 'aria-haspopup': 'dialog', title: 'Group info', onclick: () => openGroupInfo(S.chat.group) }, g.name), h('span', { class: 'grow' }),
      h('button', { class: 'btn primary sm call-group', type: 'button', title: 'Start a call and send the link to everyone in this group', onclick: () => callGroup(S.chat.group) }, h('span', { class: 'btn-ic' }, icon('video', 16)), 'Call group'),
      searchBtn(),
      h('button', { class: 'icon-btn sm', 'aria-label': 'Close chat', onclick: closeChat }, icon('x', 16))),
    h('div', { class: 'pin-bar', id: 'pin-bar', hidden: true }), searchPanel(),
    list, latestBar(), h('div', { class: 'chat-status', id: 'chat-status', role: 'status' }), form));
  wireTyping(input, { group_id: g.id });
  renderChatList(true);
  if (focus) input.focus();
  refreshNotif(); // opening the chat marked it read, so its badge clears
}

// Group info card: name, when it was created, who is in it, rename, add people, remove people (creator) and leave.
async function openGroupInfo(g) {
  const body = h('div', {}, h('p', { class: 'hint' }, 'Loading…'));
  const closeBtn = h('button', { class: 'icon-btn sm', type: 'button', 'aria-label': 'Close group info', onclick: () => m.close() }, icon('x', 16));
  const m = openModal({ label: 'Group info', wide: true, onClose: () => { if (S.groupInfo?.modal === m) S.groupInfo = null; } },
    h('div', { class: 'pop-head' }, h('strong', {}, 'Group info'), h('span', { class: 'grow' }), closeBtn), body);
  let data;
  let view = 'info'; // 'info' | 'add'
  const load = async () => {
    try { data = await api('/api/groups/' + g.id); } catch (err) { body.replaceChildren(h('p', { class: 'error' }, errText(err))); return false; }
    return true;
  };
  S.groupInfo = { id: g.id, modal: m, reload: async () => { if (await load()) render(); } }; // live refresh when someone joins or leaves
  if (!(await load())) return;
  render();

  function render() { (view === 'add' ? renderAdd : renderInfo)(); }

  function renderInfo() {
    const { group, members } = data;
    const iAmCreator = group.created_by === S.meId;
    const iAmAdmin = !!group.me_admin; // the creator, or someone the creator made an admin
    const msg = h('p', { class: 'error', role: 'alert' });
    const nameInput = h('input', { id: 'grpRename', maxlength: '40', required: true, autocomplete: 'off', value: group.name });
    const form = h('form', {}, h('label', { for: 'grpRename' }, 'Group name'), nameInput, h('button', { class: 'btn sm', type: 'submit' }, 'Save name'));
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      msg.textContent = '';
      if (nameInput.value.trim() === group.name) return;
      try {
        const r = await api('/api/groups/' + group.id, { method: 'PATCH', body: { name: nameInput.value } });
        group.name = r.name;
        applyGroupName(group.id, r.name);
        toast('Group name changed');
        render();
      } catch (err) { msg.textContent = errText(err); }
    });
    const removeMember = async (u) => {
      const ok = await confirmDialog({ title: `Remove ${u.display_name}?`, body: 'They will no longer see this group or its new messages.', confirmText: 'Remove' });
      if (!ok) return;
      try { await api(`/api/groups/${group.id}/members/${u.id}`, { method: 'DELETE' }); await load(); refreshGroups(); render(); toast(`${u.display_name} was removed`); }
      catch (err) { msg.textContent = errText(err); }
    };
    const leave = async () => {
      const ok = await confirmDialog({ title: `Leave “${group.name}”?`, body: 'You’ll stop getting its messages. Someone in the group will have to add you back to rejoin.', confirmText: 'Leave group' });
      if (!ok) return;
      try { await api(`/api/groups/${group.id}/members/${S.meId}`, { method: 'DELETE' }); m.close(); dropGroup(group.id); toast(`You left “${group.name}”`); }
      catch (err) { msg.textContent = errText(err); }
    };
    const setAdmin = async (u, admin) => {
      msg.textContent = '';
      try { await api(`/api/groups/${group.id}/members/${u.id}/admin`, { method: 'PUT', body: { admin } }); await load(); render(); toast(admin ? `${u.display_name} is now an admin` : `${u.display_name} is no longer an admin`); }
      catch (err) { msg.textContent = errText(err); }
    };
    // The creator decides who may rename the group and who may add people. Admins (and the creator) always can.
    const ruleBox = (id, label, key) => {
      const box = h('input', { type: 'checkbox', id, checked: !!group[key] });
      box.addEventListener('change', async () => {
        msg.textContent = '';
        try { await api(`/api/groups/${group.id}/settings`, { method: 'PUT', body: { [key]: box.checked } }); group[key] = box.checked; render(); }
        catch (err) { box.checked = !box.checked; msg.textContent = errText(err); }
      });
      return h('label', { class: 'check-row', for: id }, box, h('span', {}, label));
    };
    const rules = iAmCreator ? h('div', { class: 'group-rules' },
      h('h3', {}, 'Group rules'),
      ruleBox('grpRuleRename', 'Only admins can change the group name', 'only_admins_rename'),
      ruleBox('grpRuleAdd', 'Only admins can add people', 'only_admins_add'),
      h('p', { class: 'hint' }, 'You’re always an admin. Tap “Make admin” next to a member to give them the same powers.')) : null;
    // Group picture: same cropper and rules as profile pictures. Any member can change it.
    const picMsg = h('p', { class: 'error', role: 'alert' });
    const picFile = h('input', { type: 'file', accept: PICK_TYPES.join(','), hidden: true, 'aria-label': 'Choose a group picture' });
    const change = h('button', { class: 'btn sm', type: 'button', 'data-autofocus': '' }, h('span', { class: 'btn-ic' }, icon('camera', 16)), group.avatar_at ? 'Change picture' : 'Add a picture');
    change.addEventListener('click', () => picFile.click());
    const removePic = group.avatar_at ? h('button', { class: 'link-btn danger', type: 'button' }, 'Remove') : null;
    picFile.addEventListener('change', async () => {
      const f = picFile.files[0];
      picFile.value = '';
      picMsg.textContent = '';
      if (!f) return;
      if (!PICK_TYPES.includes(f.type)) { picMsg.textContent = 'Pick a PNG, JPG, WebP or GIF picture.'; return; }
      if (f.size > 3 * 1024 * 1024) { picMsg.textContent = `That file is ${(f.size / 1024 / 1024).toFixed(1)} MB. Pick one that’s 3 MB or smaller.`; return; }
      let blob;
      try { blob = await cropAvatar(f, { subject: 'group picture', hint: 'Move and zoom so the picture sits inside the circle. Everything outside it is cut off.' }); } catch { picMsg.textContent = 'We couldn’t open that picture. Try a different one.'; return; }
      if (!blob) return; // cancelled
      change.disabled = true;
      try {
        const r = await uploadChatImage(`/api/groups/${group.id}/avatar`, blob, 'PUT');
        group.avatar_at = r.avatar_at;
        applyGroupAvatar(group.id, r.avatar_at);
        toast('Group picture updated');
        render();
      } catch (err) { change.disabled = false; picMsg.textContent = errText(err); }
    });
    removePic?.addEventListener('click', async () => {
      try {
        await api(`/api/groups/${group.id}/avatar`, { method: 'DELETE' });
        group.avatar_at = null;
        applyGroupAvatar(group.id, null);
        toast('Group picture removed');
        render();
      } catch (err) { picMsg.textContent = errText(err); }
    });
    body.replaceChildren(
      h('div', { class: 'profile-head', style: 'margin-top:0' },
        groupAvatarEl(group, 88),
        h('div', {}, h('h2', { style: 'font-size:1.6rem' }, group.name), h('p', { class: 'sub' }, `Created ${fmtStamp(group.created_at)}`),
          h('div', { class: 'pic-actions' }, change, removePic))),
      picFile, picMsg,
      h('h3', {}, `Members (${members.length})`),
      h('ul', { class: 'rows' }, members.map((u) => h('li', { class: 'row' },
        avatarEl(u, 34),
        h('div', { class: 'row-main pick-text' }, h('span', { class: 'name' }, u.id === S.meId ? `${u.display_name} (you)` : u.display_name), h('span', { class: 'sub' }, '@' + u.handle)),
        u.is_creator ? h('span', { class: 'member-tag' }, 'Creator') : u.is_admin ? h('span', { class: 'member-tag' }, 'Admin') : null,
        h('span', { class: 'member-actions' },
          iAmCreator && !u.is_creator ? h('button', { class: 'link-btn', type: 'button', 'aria-label': u.is_admin ? `Remove ${u.display_name} as admin` : `Make ${u.display_name} an admin`, onclick: () => setAdmin(u, !u.is_admin) }, u.is_admin ? 'Remove admin' : 'Make admin') : null,
          u.id !== S.meId ? h('button', { class: 'link-btn danger', type: 'button', 'aria-label': `Report ${u.display_name}`, onclick: () => openReport(u, { context: { type: 'group', id: group.id } }) }, 'Report') : null,
          iAmCreator && u.id !== S.meId ? h('button', { class: 'link-btn danger', type: 'button', 'aria-label': `Remove ${u.display_name}`, onclick: () => removeMember(u) }, 'Remove') : null)))),
      group.only_admins_add && !iAmAdmin
        ? h('p', { class: 'hint add-people' }, 'Only group admins can add people to this group.')
        : h('button', { class: 'btn sm add-people', type: 'button', onclick: () => { view = 'add'; refreshFriends().then(() => view === 'add' && render()); render(); } }, h('span', { class: 'btn-ic' }, icon('userPlus', 16)), 'Add people'),
      h('h3', {}, 'Change group name'),
      group.only_admins_rename && !iAmAdmin ? h('p', { class: 'hint' }, 'Only group admins can change the group name.') : form,
      msg, ...(rules ? [rules] : []),
      h('div', { class: 'dialog-actions' }, h('button', { class: 'btn danger', type: 'button', onclick: leave }, 'Leave group')));
  }

  function renderAdd() {
    const inGroup = new Set(data.members.map((u) => u.id));
    const available = S.friends.filter((f) => !inGroup.has(f.id));
    const msg = h('p', { class: 'error', role: 'alert' });
    const add = async (f) => {
      msg.textContent = '';
      try { await api(`/api/groups/${g.id}/members`, { method: 'POST', body: { memberIds: [f.id] } }); await load(); refreshGroups(); toast(`${f.display_name} was added`); render(); }
      catch (err) { msg.textContent = errText(err); }
    };
    let list;
    if (!S.friends.length) list = h('p', { class: 'empty' }, 'You don’t have any friends yet. Friends can be added once they accept your request.');
    else if (!available.length) list = h('p', { class: 'empty' }, 'Everyone on your friend list is already in this group.');
    else list = h('ul', { class: 'rows' }, available.map((f) => h('li', { class: 'row' },
      h('div', { class: 'row-main pick-row' }, avatarEl(f, 34), h('span', { class: 'pick-text' }, h('span', { class: 'name' }, f.display_name), h('span', { class: 'sub' }, '@' + f.handle))),
      h('button', { class: 'btn primary sm', type: 'button', onclick: () => add(f) }, 'Add'))));
    body.replaceChildren(
      h('h3', { style: 'margin-top:0' }, 'Add people to the group'),
      h('p', { class: 'hint' }, 'You can add your friends. They won’t see messages from before they joined.'),
      list, msg,
      h('div', { class: 'dialog-actions' }, h('button', { class: 'btn', type: 'button', 'data-autofocus': '', onclick: () => { view = 'info'; render(); } }, 'Back')));
  }
}
// You're no longer in this group (you left, were removed, or it was deleted): tidy up everywhere it showed.
function dropGroup(id) {
  S.groups = S.groups.filter((x) => x.id !== id);
  if (S.chat?.group?.id === id) closeChat();
  if (S.groupInfo?.id === id) S.groupInfo.modal.close();
  renderFriends();
  refreshNotif();
}
function applyGroupAvatar(id, at) {
  const g = S.groups.find((x) => x.id === id);
  if (g) g.avatar_at = at;
  const c = S.chats.find((x) => x.type === 'group' && x.id === id);
  if (c) c.avatar_at = at;
  if (S.chat?.group?.id === id) {
    S.chat.group.avatar_at = at;
    document.getElementById('group-pic')?.replaceChildren(groupAvatarEl(S.chat.group, 28));
  }
  renderFriends();
  if (!panels.chats.hidden) renderChats();
}
function applyGroupName(id, name) {
  const g = S.groups.find((x) => x.id === id);
  if (g) g.name = name;
  if (S.chat?.group?.id === id) {
    S.chat.group.name = name;
    const t = document.getElementById('group-title');
    if (t) t.textContent = name;
    document.getElementById('group-input')?.setAttribute('placeholder', `Message ${name}`);
  }
  renderFriends();
}

/* ---------- realtime ---------- */
function connect() {
  const socket = window.io();
  sock = socket;
  api('/api/me').then((r) => { S.share = r.user.share_activity; notify.setStatus(r.user.status); setMyStatus(r.user.status); startAutoStatus(); }).catch(() => {});
  // A status can end by itself ("clear after 1 hour"): redraw now and then so friends' lists don't show a stale one.
  setInterval(() => {
    let changed = false;
    for (const f of S.friends) if (f.status && !activeStatus(f.status)) { f.status = null; changed = true; }
    if (changed) { renderFriends(); paintDmStatus(); if (!panels.chats.hidden) renderChats(); }
  }, 30_000);
  window.addEventListener('activity-updated', (e) => { // the switch in Settings
    S.share = e.detail;
    if (!S.share) { stopTyping(); clearTyping(); }
    renderChatList(false);
  });
  socket.on('connect', () => { refreshFriends(); refreshGroups(); refreshNotif(); });
  // Tapping a browser notification brings this tab forward and opens that chat.
  const openFromNotification = (o) => {
    window.focus();
    if (o?.kind === 'bell') { if (panels.notif.hidden) togglePanel('notif'); }
    else if (o?.kind === 'group' && Number.isInteger(o.id)) openGroupChat({ id: o.id, name: String(o.name ?? '') });
    else if (o?.kind === 'dm' && Number.isInteger(o.id)) openChat({ id: o.id, handle: o.handle, display_name: String(o.name ?? '') });
  };
  notify.onOpen(openFromNotification);
  // A push notification tapped while Knock was closed opens /dashboard?open=<what to show>.
  try {
    const q = new URLSearchParams(location.search).get('open');
    if (q) { history.replaceState(null, '', location.pathname); openFromNotification(JSON.parse(q)); }
  } catch { /* ignore a malformed link */ }
  // Someone edited, deleted or pinned a message (or I did, in another tab).
  socket.on('message:changed', ({ kind, group_id: gid, message }) => applyChange(message, kind, gid));
  // The other person opened the chat: show "Seen" under everything of mine they hadn't read.
  socket.on('dm:read', ({ by, at }) => {
    if (S.chat?.user?.id !== by) return;
    S.chat.messages.forEach((m) => { if (m.from_id !== by && !m.read_at) m.read_at = at; });
    renderChatList(false);
  });
  socket.on('group:read', ({ group_id: gid, user_id: uid, name, last_read_id: last }) => {
    if (S.chat?.group?.id !== gid) return;
    const r = S.chat.reads.find((x) => x.id === uid);
    if (r) { r.last_read_id = last; r.name = name; } else S.chat.reads.push({ id: uid, name, last_read_id: last });
    renderChatList(false);
  });
  socket.on('typing', ({ from, name, group_id: gid, on }) => {
    if (!S.share || !S.chat) return;
    const here = gid != null ? S.chat.group?.id === gid : !S.chat.group && S.chat.user.id === from;
    if (!here) return;
    const old = S.typing.get(from);
    if (old) clearTimeout(old.timer);
    if (on) S.typing.set(from, { name, timer: setTimeout(() => { S.typing.delete(from); paintTyping(); }, 5000) });
    else S.typing.delete(from);
    paintTyping();
  });
  socket.on('dm:echo', () => refreshChats());
  socket.on('presence', ({ id, online }) => {
    const f = S.friends.find((x) => x.id === id);
    if (f) { f.online = online; sortFriends(); renderFriends(); }
  });
  // A friend (or I, in another tab) changed their status.
  socket.on('status', ({ id, status }) => {
    if (id === S.meId) { notify.setStatus(status); setMyStatus(status); return; }
    const f = S.friends.find((x) => x.id === id);
    if (f) { f.status = status; renderFriends(); paintDmStatus(); if (!panels.chats.hidden) renderChats(); }
  });
  // A new message opens its chat box by itself, unless you're already in another chat (we never swap it out
  // from under you while you type) or it's from someone who isn't your friend (that goes to Spam).
  socket.on('dm:new', (m) => {
    if (!m.spam) notify.show({ title: m.from.display_name, body: previewText(m.body), tag: `dm-${m.from_id}`, open: { kind: 'dm', id: m.from_id, name: m.from.display_name, handle: m.from.handle } }); // Spam never alerts
    if (S.chat?.user?.id === m.from_id) { appendMsg(m); api('/api/messages/with/' + m.from_id).finally(refreshNotif); }
    else if (!S.chat && !m.spam) openChat({ ...m.from, id: m.from_id }, { focus: false });
    else refreshNotif();
  });
  socket.on('dm:echo', (m) => { if (S.chat?.user?.id === m.to_id) appendMsg(m); });
  // Friend requests: someone asked, answered, cancelled, or you unfriended. Refresh the lists and the bell.
  socket.on('friends:changed', () => { refreshFriends(); refreshNotif(); });
  socket.on('group:new', ({ group, by }) => { if (!S.groups.some((g) => g.id === group.id)) S.groups.unshift(group); renderFriends(); refreshNotif(); toast(`${by} added you to the group “${group.name}”`); });
  socket.on('group:msg', ({ group_id: gid, group_name: gname, message }) => {
    const open = S.chat?.group?.id === gid;
    refreshChats(); // the Chats list shows the newest message and order
    if (open) appendMsg(message);
    if (message.kind === 'system') return; // "Sam left" notes never alert
    if (message.from_id !== S.meId) notify.show({ title: gname, body: `${message.from_name}: ${previewText(message.body)}`, tag: `group-${gid}`, open: { kind: 'group', id: gid, name: gname } });
    if (open) { if (message.from_id !== S.meId) api(`/api/groups/${gid}/read`, { method: 'POST' }).finally(refreshNotif); }
    else if (message.from_id !== S.meId) {
      if (!S.chat) openGroupChat(S.groups.find((x) => x.id === gid) || { id: gid, name: gname }, { focus: false });
      else { refreshNotif(); toast(`${message.from_name} in ${gname}: ${message.body.slice(0, 60)}`); }
    }
  });
  socket.on('group:renamed', ({ group_id: gid, name }) => applyGroupName(gid, name));
  socket.on('group:avatar', ({ group_id: gid, avatar_at: at }) => applyGroupAvatar(gid, at));
  // Someone reacted (or took a reaction back) in a chat: update that message if it's on screen.
  socket.on('reaction:update', ({ kind, group_id: gid, message_id: mid, reactions }) => {
    const c = S.chat;
    if (!c || (kind === 'group' ? c.group?.id !== gid : !!c.group)) return;
    const m = c.messages.find((x) => x.id === mid);
    if (!m) return;
    m.reactions = reactions;
    renderChatList(false);
  });
  socket.on('group:members', ({ group_id: gid }) => { refreshGroups(); if (S.groupInfo?.id === gid) S.groupInfo.reload(); });
  socket.on('group:removed', ({ group_id: gid, group_name: gname, left }) => {
    if (!S.groups.some((g) => g.id === gid)) return; // already handled in this tab
    dropGroup(gid);
    if (!left) toast(`You were removed from “${gname}”`);
  });
  socket.on('notif:new', () => refreshNotif());
  socket.on('connect_error', (e) => { if (e.message === 'captcha_required') location.href = '/verify?next=' + encodeURIComponent(location.pathname); });
}
